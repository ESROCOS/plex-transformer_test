/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_vizkit3d_rigidbodystate__
#define __USER_CODE_H_vizkit3d_rigidbodystate__

#include "C_ASN1_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

void vizkit3d_rigidbodystate_startup();

void vizkit3d_rigidbodystate_PI_updateRigidBodyState(const asn1SccBase_samples_RigidBodyState *);

#ifdef __cplusplus
}
#endif


#endif
